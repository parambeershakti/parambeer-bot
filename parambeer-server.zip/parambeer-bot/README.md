# Param Beer Shakti — CoinDCX Funding Bot Server

## Deploy on Railway:
1. GitHub pe upload karo
2. Railway pe connect karo
3. Deploy!

## Endpoints:
- GET  /          — Health check
- GET  /funding   — Funding rate + countdown
- POST /order/place — Order place
- POST /order/close — Order close
- GET  /coins     — All coins list
